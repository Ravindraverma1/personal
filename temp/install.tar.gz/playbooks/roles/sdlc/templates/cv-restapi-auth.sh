#!/bin/bash

userid=$1
userpwd=$2
serverURI=$3

authURI=$(echo ${serverURI}/rest/axiomAuthentication/authenticatePassword)
authData="userName=$userid&password=$userpwd"
curlCommand="curl -k --silent -X POST -H \"Content-Type: application/x-www-form-urlencoded\" -H \"Cache-Control:no-cache\" --data \"$authData\" \"$authURI\""
authResponse=$(eval ${curlCommand})
if [ -z "$authResponse" ];then
    echo "${authResponse}"
    exit 1
fi

status=$(grep -oP '(?<=responseStatus" value=")[-\d]+(?=")' <<< "$authResponse")
ret=$?

if [ -z "$status" ] || [ "$ret" -ne 0 ];then
    echo "status: ${status}"
    echo "authResponse: ${authResponse}"
    exit 1
fi
REST_SESSION=$(grep -oP '(?<=JSESSIONID" value=")[\d\w]+(?=")' <<< "$authResponse")
echo ${REST_SESSION}
exit 0
